"""Bias controls must bind reviews to bytes and keep analysis strata private."""
import csv
import hashlib
from itertools import product
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from pipeline import build, evaluate as ev, freeze


def write_rows(path, rows):
    with path.open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


class OracleBindingTests(unittest.TestCase):
    def test_identical_bytes_rebind_but_changed_source_or_binary_requires_review(self):
        for changed in (None, 'source', 'reference'):
            with self.subTest(changed=changed), tempfile.TemporaryDirectory() as directory:
                root = Path(directory)
                (root/'data/private').mkdir(parents=True)
                for name in ('source', 'reference'):
                    (root/name).write_bytes(b'original')
                sha = hashlib.sha256(b'original').hexdigest()
                review = dict(pair_id='p13', variant='fixed', optimization='O0',
                              source_path='source', source_sha256=sha,
                              oracle_binary='old-generation/reference', oracle_sha256=sha,
                              source_capacity_bytes='8', capacity_basis='reviewed capacity',
                              intended_write_interval='[0,8)', observed_write_intervals='[0,8)',
                              evidence_addresses='0x1000', source_truth='not_vulnerable',
                              conclusion='not_vulnerable', reviewer='reviewer',
                              review_notes='reviewed writes', intended_operation_survived='yes',
                              review_status='reviewed')
                path = root/'data/private/manual_oracle.csv'
                write_rows(path, [review])
                if changed:
                    (root/changed).write_bytes(b'changed')
                observation = dict(pair_id='p13', variant='fixed', optimization='O0',
                                   source_path='source', oracle_binary='reference')
                with patch.object(build, 'PROJECT_ROOT', root):
                    # The retained/stripped observations share one review.
                    build.rebind_oracle([observation, observation])
                with path.open(newline='') as stream:
                    actual, = csv.DictReader(stream)
                self.assertEqual(actual['oracle_binary'], 'reference')
                self.assertEqual(actual['source_sha256'], build.file_sha256(root/'source'))
                self.assertEqual(actual['oracle_sha256'], build.file_sha256(root/'reference'))
                self.assertEqual(actual['review_status'], 'pending' if changed else 'reviewed')
                self.assertEqual(actual['conclusion'], '' if changed else 'not_vulnerable')
                self.assertEqual(actual['evidence_addresses'], '' if changed else '0x1000')

    def test_freeze_requires_bounds_evidence_inside_the_reviewed_target(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root/'data/private').mkdir(parents=True)
            (root/'source').write_bytes(b'source')
            (root/'reference').write_bytes(b'reference')
            (root/'analysis').write_bytes(b'analysis')
            observations, reviews = [], []
            for index in range(80):
                row = dict(pair_id=f'p{index}', variant='fixed', optimization='O0',
                           source_path='source', oracle_binary='reference', analysis_binary='analysis',
                           truth='not_vulnerable', target_start='0x1000', target_end='0x1010')
                observations.extend(dict(row, observation_id=f'r{2*index+offset:04d}') for offset in (1, 2))
                reviews.append(dict(pair_id=row['pair_id'], variant='fixed', optimization='O0',
                                    source_path='source', oracle_binary='reference',
                                    source_sha256=build.file_sha256(root/'source'),
                                    oracle_sha256=build.file_sha256(root/'reference'),
                                    source_capacity_bytes='8', capacity_basis='allocation argument',
                                    intended_write_interval='[0,8)', observed_write_intervals='[0,8)',
                                    evidence_addresses='0x1001', source_truth='not_vulnerable',
                                    conclusion='not_vulnerable', review_status='reviewed', reviewer='reviewer',
                                    intended_operation_survived='yes'))
            write_rows(root/'data/private/observations.csv', observations)
            path = root/'data/private/manual_oracle.csv'
            with patch.object(freeze.extract, 'binary_hashes', return_value={}):
                write_rows(path, reviews)
                freeze.validate_oracle(root)
                reviews[-1]['observed_write_intervals'] = ''
                write_rows(path, reviews)
                with self.assertRaisesRegex(ValueError, 'lacks bounds/write evidence'):
                    freeze.validate_oracle(root)
                reviews[-1]['observed_write_intervals'] = '[0,8)'
                reviews[-1]['evidence_addresses'] = '0x1010'
                write_rows(path, reviews)
                with self.assertRaisesRegex(ValueError, 'outside target'):
                    freeze.validate_oracle(root)


class StratumTests(unittest.TestCase):
    def test_cohort_and_volatile_results_are_descriptive_not_matched_treatments(self):
        truth = [dict(observation_id=f'r{i}-{opt}-{symbol}', pair_id=f'p{i}', truth='not_vulnerable',
                      cohort='original' if i < 2 else 'extension',
                      volatile_destination='no' if i < 3 else 'yes', optimization=opt,
                      symbols=symbol, cwe='CWE-121', variant='fixed')
                 for i, opt, symbol in product(range(4), ('O0', 'O2'), ('retained', 'stripped'))]
        pairs = sorted({row['pair_id'] for row in truth})
        predictions = {row['observation_id']: dict(decision='not_vulnerable') for row in truth}
        rows, contexts = ev.build_subgroups(truth, dict.fromkeys(ev.METHODS, predictions),
                                           pairs, ev.bootstrap_weights(pairs, 100, 12))
        for method in ev.METHODS:
            for cohort in ('original', 'extension'):
                self.assertEqual(contexts[method, 'cohort', cohort]['point']['n'], 8)
            self.assertEqual(contexts[method, 'volatile_destination', 'yes']['point']['n'], 4)
        self.assertFalse(any(row['kind'] == 'matched_contrast'
                             and row['group'] in ('cohort', 'volatile_destination') for row in rows))
        # Exercise the actual report writer so these caveats cannot disappear
        # while subgroup CSVs continue to look correct.
        weights = ev.bootstrap_weights(pairs, 100, 12)
        overall = {method: ev.context(truth, predictions, pairs, weights) for method in ev.METHODS}
        runs = {row['observation_id']: [dict(status='valid', parsed=dict(
            decision='not_vulnerable', confidence=.5)) for _ in range(3)] for row in truth}
        aggregates = {identifier: ev.aggregate_three_runs(group) for identifier, group in runs.items()}
        _, stability = ev.summarize_stability(truth, runs, aggregates, .8)
        audit = dict(collision_audit=dict(full_record=dict(conflicting_ids=['r0', 'r1'])),
                     stripping_matches=[dict(equal_after_name_normalization=True)],
                     distinguishable_sensitivity=dict(methods={
                         'static': dict(correct=14, n=14, coverage=1.)}))
        with tempfile.TemporaryDirectory() as directory:
            ev.write_report(Path(directory), truth, overall, contexts, [], rows, stability,
                            rows, {'evaluation': dict(bootstrap_repetitions=100, bootstrap_seed=12)},
                            diagnostics=audit)
            report = (Path(directory)/'report.md').read_text()
        for phrase in ('not an untouched held-out validation', 'neither is an untouched test set',
                       'descriptive comparisons', '2 observations have conflicting source labels',
                       'It does not test loss of meaningful developer symbols',
                       'Differences cannot be attributed to LLM reasoning alone'):
            self.assertIn(phrase, report)
