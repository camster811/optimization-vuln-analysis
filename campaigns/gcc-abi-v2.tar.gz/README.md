# Corrected GCC ABI campaign, static method revision 2

The 80 records and 240 saved LLM attempts are a post-review corrected experiment.
The original Windows-ABI campaign is preserved separately. Final v1 results were
inspected before this revision. See analysis_plan.md for the amendment and
results/report.md, results/exploratory.md, and results/qualitative.md for results.

Install requirements.txt in a Python environment, then run:

```bash
python pipeline/freeze.py check
python pipeline/evaluate.py --check
```

Offline regeneration validates the source/oracle/analysis binaries in this
archive and reruns the static interpreter; it needs no running Ghidra/model.
The stored runtime identity records the original live server for inference.
An independent human oracle review and timestamped publication deposit remain
external work. The executable and source-tree hashes identify the local
llama.cpp installation, whose upstream Git revision was unavailable.
