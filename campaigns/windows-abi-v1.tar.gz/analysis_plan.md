# Analysis plan

This plan applies to the held-out final campaign. The two pilot pairs are
development data and are excluded from every final table, interval, and figure.
The final corpus has 10 pairs (five per CWE), eight observations per pair, and
80 observations. Treatments cross vulnerable/fixed variants, O0/O2 optimization,
and retained/stripped symbols. Each LLM observation has three stateless runs.

Every LLM request uses the frozen prompt and response schema, with a 4096-token
completion budget and the configured three seeds. No pilot observations are
included in final evaluation.
The final campaign uses an 8192-token context, all GPU layers, flash attention,
512/128 batch/microbatch sizes, 12 generation/batch threads, f16 KV caches, and
automatic fitting disabled. These explicit runtime settings and the launcher
are frozen before this complete campaign restart; abandoned attempts are excluded.

The research question is how optimization and practical stripping affect
recognition of the selected buffer write. We examine whether the LLM differs
from the static baseline, and whether optimization or stripping changes either
method's performance. These are exploratory comparisons, not a general claim
about vulnerability scanners or unseen programs. No directional hypothesis or
minimum effect is imposed after seeing final results.

Decisions are indivisible labels: `vulnerable_CWE-121`, `vulnerable_CWE-122`,
`not_vulnerable`, and `uncertain`. Two identical valid votes establish the LLM
decision. With no valid runs it is `unavailable`; otherwise a missing majority
is `uncertain_due_to_insufficient_agreement`. Confidence is the median over all
valid runs, including votes outside the majority. Invalid runs stay unavailable
and are counted by their recorded failure status; they are never retried or
converted into model-produced `uncertain` votes.

Three-way correctness requires the exact truth label, including the CWE.
Both uncertainty types abstain; unavailability is separate. Report counts,
correct/N, coverage=(correct+incorrect)/N, abstain/N, unavailable/N, and selective
accuracy=correct/(correct+incorrect). Always accompany selective accuracy with
coverage and the underlying correct/incorrect/abstain/unavailable counts.

Forced-alert scoring maps either vulnerable label to alert and everything else
to no alert. Thus a wrong-CWE alert can be a forced TP while being three-way
incorrect. Report TP/TN/FP/FN, accuracy, balanced accuracy, precision, recall,
F1, FPR, and FNR. Identify TN and FN counts caused by abstentions and unavailable
results separately from explicit `not_vulnerable` decisions.

Primary paired comparisons are LLM majority minus static for correct/N,
coverage, forced recall, and forced FPR. Also retain the other metric differences.
Subgroups are O0/O2, retained/stripped, CWE-121/CWE-122, and vulnerable/fixed.
Within each method, compare O2 minus O0 and stripped minus retained using the
same complete pairs and matched variant/other-treatment cells. Never drop a
failed observation or replace a failed pair after viewing final performance.

Use the 10 final pair IDs as clusters. Generate 10,000 draws of 10 IDs with
replacement using the configured fixed bootstrap seed and NumPy PCG64. Include
all rows of each sampled pair, with multiplicity. Share these weights across
methods, subgroups, and both sides of every contrast. Intervals are the 2.5th and
97.5th percentiles with linear interpolation. There is no GLMM, significance
testing ladder, or multiplicity-adjusted confirmatory claim. With only 10
clusters these intervals are exploratory and may be unstable.

A rate with a zero denominator is undefined, not zero. Balanced accuracy is
undefined unless both truth classes are present. For a bootstrap interval, use
only replicates where that metric (or both sides of a difference) is defined;
report the number of defined replicates out of 10,000. An entirely undefined
estimate or interval is blank in CSV and NA in the report. These conditional
intervals need particular caution for sparse subgroups.

LLM stability includes three-valid-run counts, three-identical-decision counts
(requiring all three to be valid), pooled pairwise agreement among valid runs,
failure counts by status, and separate model-uncertainty, aggregation-uncertainty,
and all-unavailable counts. Confidence summaries use observation medians grouped
by three-way outcome. A high-confidence error is a three-way incorrect LLM
aggregate whose median confidence is at least the frozen configured threshold.

Produce only coverage/selective-accuracy, recall/FPR, and treatment-accuracy PNG
figures. Keep optimization and symbol panels separate. Report all exclusions
and failures; valid JSON is not evidence of classification correctness.
Qualitative examples, if added, illustrate observed disagreement, abstention,
or errors with evidence addresses; they do not change eligibility or metrics.
The release manifest binds the qualitative file when present.

Freeze this plan, settings, analyzer inputs, and method files before the final
campaign. Do not infer or fabricate a freeze from already completed final runs.
Create it with `python3 pipeline/freeze.py create` after final extraction and
before either final analyzer; verify it with `python3 pipeline/freeze.py check`.
Regeneration must reproduce every managed output byte for byte; no timestamps,
hostnames, or absolute machine paths appear in generated tables or reports.
