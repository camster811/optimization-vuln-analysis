# optimization-vuln-analysis
How do GCC optimization and practical symbol stripping affect the ability of a static baseline and a local LLM to recognize known CWE-121 and CWE-122 instances in matched x86-64 binary functions?

The static baseline reads only exported JSON records. It uses machine instructions
and call targets, independently of decompilation status or text. Extraction retains
complete, validated instruction exports if decompilation alone fails or times out;
lookup failures, partial extraction, incorrect bounds, and metadata leaks remain
fatal. Decompilation diagnostics stay in the record for downstream methods.

Prediction `evidence` lists contain **key evidence locations**, not complete
provenance traces. They can omit instructions establishing destination addresses,
allocation arguments, or copy lengths. The stack rule
`stack_write_overlaps_saved_frame_state` detects overlap with a saved frame-pointer
slot or the return-address slot and identifies which slot was affected. It does
not recover the source array boundary or the complete frame-local area.

Builds are staged as a complete split. Successful artifacts are published under
immutable, content-addressed generation directories inside `build/oracle`,
`build/retained`, and `build/stripped`; the observation table is replaced last.
Failed builds cannot overwrite the generation referenced by an existing table.
Attempt logs, including failed attempts, live in `build/logs/build-*`.
`analysis_sha256` binds each row to the full retained/stripped ELF;
`text_sha256` separately establishes executable-code equality. Extraction verifies
both hashes on one byte snapshot immediately before writing those exact bytes
into its fresh Ghidra workspace. Hashes are never exported to analyzer records.

The exporter requires one contiguous function-body range. `calls` contains direct
calls and direct jumps outside that body (tail calls); local branches appear only
in `instructions`. Disjoint bodies are rejected rather than flattened into false
fallthrough.

`check_memory_write` is only an early rejection gate: a compiler spill can pass.
It does not certify that the intended copy survived. The separate private
worksheet [manual_oracle.csv](data/private/manual_oracle.csv) records source
capacity, intended and observed write intervals, relevant addresses, survival,
and the vulnerable/fixed conclusion. Reviewed rows bind to full oracle and source
hashes and name their reviewer; changing either input requires a new review.
Stack conclusions use declared source capacities, not decompiler array sizes or
the whole stack reservation. All 48 pair/variant/optimization combinations have
been reviewed. All forty final build binaries and their sources were hash-matched
to those reviews, and the worksheet now references the published final generation.
The final build contains ten held-out pairs and 80 analysis observations.
Build and extract it with `python3 pipeline/build.py --split final` and
`python3 pipeline/extract.py --split final` (with `GHIDRA_HOME` configured).
For the alloca pairs at O2, vulnerable and fixed targets have identical copy
instructions and aligned reservations; the requested capacities are source
ground truth, not distinguishable binary object bounds. Stale rows are not
evidence of survival. The worksheet is never an input to either analyzer.

The LLM runner uses the frozen [prompt](llm/prompt.md) and
[response schema](llm/response.schema.json). Each request contains one user
message with canonical, sorted-key record JSON, and uses llama.cpp's nested
`response_format.json_schema.schema` for grammar-constrained generation
([llama.cpp grammar documentation](https://github.com/ggml-org/llama.cpp/blob/master/grammars/README.md)).
Confidence bounds, nonblank summaries, and evidence membership are also checked
locally; llama.cpp does not enforce every JSON Schema constraint in its grammar.
Reasoning is separated from answer content with `reasoning_format=deepseek`;
the entire HTTP response, including reasoning and errors, is retained in
`response_body`, while `raw_response` contains the unmodified answer text.

Start the local server with the frozen runtime configuration:

```bash
python3 pipeline/serve_llm.py --print-command
python3 pipeline/serve_llm.py
```

The launcher reads `config.json`, checks the model SHA-256, and explicitly uses
an 8192-token context, one slot, all GPU layers, flash attention, 512/128
batch/microbatch sizes, 12 generation/batch threads, f16 key/value caches,
no context shifting, DeepSeek reasoning separation, and `--fit off`. Trace-level
startup logs expose the offload and attention settings. The local installation
and model paths are under `llama_cpp` in the configuration.

Before inference, verify `offloaded 49/49 layers to GPU` and
`flash_attn = enabled`, then tokenize every chat-templated request and check that
its input plus the 4096-token output budget fits the 8192-token context. Token
preflight does not generate answers. The full campaign is restarted and frozen
with these settings; abandoned attempts are excluded from final results.

`python3 pipeline/run_llm.py` selects `data/records` and `results/llm_runs`.
There are three repetitions per input: the current 16-record pilot has 48 tasks;
the 80-record final dataset has 240. All tasks are sorted and then shuffled once
with the configured schedule seed. No private table or build artifact is read.
`campaign.json` saves the exact schedule, inference settings, prompt/schema
hashes, and hashes of the complete request payloads. These bind resumption to
the same inputs and frozen settings.

The model returns a decision, confidence, zero to five evidence addresses, and
a short summary. All evidence addresses must occur in the supplied record.
The final completion budget is 4096 tokens; every scheduled repetition gets one
attempt. The original 16-record pilot used 2048 output tokens; its saved results
and failures remain development-only. Changed settings require a separate pilot
output directory rather than overwriting those completed runs.

Use `--resume` with the same input/output arguments after interruption. It skips
validated completed files, including saved inference failures, and replaces
malformed/incomplete files with one new attempt. A different request or campaign
requires a separate output directory or explicit `--force`, which reruns every
scheduled task. A file lock prevents concurrent runners in the same output
directory. Each run is flushed and atomically renamed into place. There are no
inference retries or output repairs; failures remain unavailable runs rather
than `uncertain` votes. Transport timeouts use the configured 600-second read
timeout. A crash before a final run file is published leaves that task incomplete.

After final extraction and before running either final analyzer, create and
verify the input freeze:

```bash
python3 pipeline/freeze.py create
python3 pipeline/freeze.py check
```

Creation requires all 80 final records and all 12 corpus sources (two pilot,
ten final). It validates record structure and leak checks, refuses an existing
nonempty freeze, and refuses final campaign files or analysis outputs. Pilot
campaigns do not block it. The initial empty freeze placeholder can be replaced;
there is no overwrite or retrospective-freeze option. Creation writes a sorted,
timestamp-free SHA-256 inventory atomically after rechecking the inputs.
`check` works after inference and detects changed contents, missing files, and
additions to the source/record inventory without modifying anything.

The final evaluator joins the saved methods to the private truth for the ten
held-out pairs (80 observations, 240 LLM runs). It requires a nonempty
[analysis plan](analysis_plan.md), complete final truth/records/predictions, and
an existing `data/input_freeze.json`; it never creates a retrospective freeze or
substitutes pilot results. Activate the environment containing `requirements.txt`
dependencies, then run:

```bash
source .venv/bin/activate
python3 pipeline/evaluate.py
python3 pipeline/evaluate.py --check
```

The input freeze uses `{"freeze_version":1,"files":{"project/relative/path":"sha256"}}`.
It must bind the plan, configuration, requirements, corpus manifest and all corpus
sources, 80 final records, Ghidra exporter, static/LLM methods, prompt, and response
schema, plus the server launcher, build scripts, extractor validator, evaluator,
and freeze script themselves.
The evaluator shares the freeze tool's exact inventory and hash validation.
Build logs, temporary projects, virtual environments, results, and the input
freeze itself are excluded. The evaluator additionally verifies LLM
campaign/request hashes, seeds, evidence, and all 240 saved run files. It works
from the records and saved predictions without requiring build binaries or a
running Ghidra/model server. All consumed input hashes are captured before
analysis and rechecked before publishing.

`summary.csv` and `subgroups.csv` use long-form metric rows with point estimates,
95% intervals, and the number of defined bootstrap replicates. Method rows also
carry correct/incorrect/abstain/unavailable counts, coverage, and selective
accuracy. Difference rows reference their two method/condition rows. Zero
denominators are blank, never silently zero. Bootstrap differences use jointly
defined replicates and shared pair weights; matched treatments retain all pairs.
The bootstrap uses ten pair clusters and 10,000 replicates. These small-cluster
intervals are exploratory and may be unstable. `stability.csv` contains aggregate
summaries and each observation's vote/failure counts, aggregate decision,
confidence, and agreement. Model uncertainty, insufficient agreement, and
unavailability remain distinct.

The other outputs are `report.md`, exactly three PNGs in `results/figures`, and
`release_manifest.json`. The manifest hashes inputs, private truth, saved
predictions, evaluator/validation code, generated artifacts, and optional
`results/qualitative.md`. It records normalized package versions and no hostnames
or timestamps. PNGs use a fixed Agg renderer/style and metadata; regeneration
requires the same rendering dependencies. `--check` regenerates everything in a
temporary directory and rejects missing, extra, or byte-changed outputs without
writing published artifacts. Its output scope is `results/`, excluding method
inputs (`static_predictions.jsonl`, `llm_runs`), optional qualitative evidence,
and the development-only `pilot` directory.
